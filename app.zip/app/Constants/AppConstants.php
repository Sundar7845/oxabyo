<?php

namespace App\Constants;

class AppConstants
{

    # =============================================
    # =              EVENT_FIELD                  =
    # =============================================

    const EVENT_FIELD_TYPE_TEXT = 1;
}
