<?php

namespace App\Services;

/* Interfaces */
use App\Services\Interfaces\CommentServiceInterface;

class CommentService implements CommentServiceInterface
{


    public function send()
    {
       
    }
}
