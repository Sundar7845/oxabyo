<form id="comment">
	<div class="row">
		<div class="col-sm-12 m_b10">
			<label>Commenta</label>
			<textarea class="form-control" rows="6" placeholder="Il mio commento...."></textarea>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6 m_b10">
			<a data-toggle="modal" data-target="#moodgramModal" class="btn btn-default"><img src="img/glifo_icon.svg" class="m_r10" style="height:16px;">Aggiungi un mood</a>
		</div>
		<div class="col-sm-6 m_b10 text-right">
			<button type="submit" class="btn btn-default">Invia</button>
		</div>
	</div>
	<pre>se è stato scelto un moodgram</pre>
	<div class="row">
		<div class="col-sm-12 m_b10">
			<label>Commenta</label>
			<textarea class="form-control" rows="6" placeholder="Il mio commento...."></textarea>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<?php include('includes/cluster.php') ?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6 m_b10">
			<a class="btn btn-default"><img src="img/glifo_icon.svg" class="m_r10" style="height:16px;">Rimuovi questo mood</a>
		</div>
		<div class="col-sm-6 m_b10 text-right">
			<button type="submit" class="btn btn-default">Invia</button>
		</div>
	</div>
</form>
