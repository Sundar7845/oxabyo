<?php include('includes/head.php') ?>
<?php include('includes/header.php') ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="text-center">
				<h3><b><i class="fas fa-bell m_r10"></i>Notification</b></h3>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<img src="https://via.placeholder.com/1200x300">

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<div class="row">
				<div class="col-sm-2">01/01/2021 00:00</div>
				<div class="col-sm-10"><b><a href="###-###">Lorem ipsum</a></b></div>
			</div>

			<hr>
			<img src="https://via.placeholder.com/1200x600">

		</div>
	</div>
</div>

<?php include('includes/footer.php') ?>
<?php include('includes/modal.php') ?>
<?php include('includes/foot.php') ?>
