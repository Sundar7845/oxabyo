<?php include('includes/head.php') ?>
<?php include('includes/g_header.php') ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h1>Privacy Policy</h1>
		</div>
	</div>
</div>

<?php include('includes/footer.php') ?>
<?php include('includes/modal.php') ?>
<?php include('includes/foot.php') ?>
